﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse;

namespace Radiology
{
    [DefOf]
    public class Globals
    {
        static public RadiologyEffectSpawnerDef RadiologyEffectBurn;
    }
}
