﻿using Verse;

namespace Radiology
{
    public interface IRadiationReciever
    {
        Building Building { get; }
    }
}