# Radiology

Adds the ability to bombard your colonists with harmful radiation, obtaining either amazing mutations, or burns and cancer.
